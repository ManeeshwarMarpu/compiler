package visitor;
import java.util.*;

public class regstatus{
    public String tmp;
    public String reg;
    public Integer loc;
    public regstatus(String tmp, String reg){
      this.tmp = tmp;
      this.reg = reg;
      this.loc = -1;
    }
  }