package visitor;
import java.util.*;

public class inout{

  public ArrayList<String> in;
  public ArrayList<String> out;

  public inout(){
    this.in  = new ArrayList<String>();
    this.out  = new ArrayList<String>();
  }
}