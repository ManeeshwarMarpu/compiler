package visitor;
import java.util.*;

public class liveness{
    public String tmp;
    public int[] range;
    public String reg;
    public liveness(String tmp, int[] range){
      this.tmp = tmp;
      this.range = range;
      this.reg = "";
    }
  }